﻿namespace LeaveManagement.Models
{
    public enum LeaveStatus { Pending, Approved, Rejected }
    public class LeaveRequest
    {
        
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string LeaveType { get; set; }
        public LeaveStatus Status { get; set; } = LeaveStatus.Pending;

       


    }
}
