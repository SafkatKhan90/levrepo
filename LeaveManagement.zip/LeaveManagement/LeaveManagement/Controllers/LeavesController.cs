﻿using LeaveManagement.Models;
using LeaveManagement.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace LeaveManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    [Route("api/leaves")]
    public class LeavesController : ControllerBase
    {
        private readonly LeaveService _service;
        public LeavesController(LeaveService service) => _service = service;

        [HttpPost]
        public IActionResult RequestLeave(LeaveRequest req)
        {
            if (req.ToDate <= req.FromDate)
                return BadRequest("ToDate must be after FromDate");

            if (!_service.IsLeaveDurationValid(req.FromDate, req.ToDate))
                return BadRequest("Leave duration exceeds 15 days");

            if (_service.IsOverlappingLeave(req.EmployeeId, req.FromDate, req.ToDate))
                return BadRequest("Overlapping leave exists for this employee");

            req.Id = _service.LeaveRequests.Count + 1;
            _service.LeaveRequests.Add(req);
            return Ok(req);
        }

        [HttpGet]
        public IActionResult GetLeaves() => Ok(_service.LeaveRequests);

        [HttpPut("{id}/status")]
        public IActionResult UpdateStatus(int id, [FromBody] dynamic body)
        {
            var leave = _service.LeaveRequests.FirstOrDefault(l => l.Id == id);
            if (leave == null) return NotFound();

            string status = body.status;
            if (Enum.TryParse<LeaveStatus>(status, out var parsedStatus))
                leave.Status = parsedStatus;
            else
                return BadRequest("Invalid status");

            return Ok(leave);
        }
    }
}
