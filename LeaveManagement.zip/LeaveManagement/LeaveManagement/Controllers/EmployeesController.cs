﻿using LeaveManagement.Models;
using LeaveManagement.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace LeaveManagement.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    [Route("api/employees")]
    
    public class EmployeesController : ControllerBase
    {
        private readonly LeaveService _service;
        public EmployeesController(LeaveService service) => _service = service;

        [HttpPost]
        public IActionResult AddEmployee(Employee emp)
        {
            emp.Id = _service.Employees.Count + 1;
            _service.Employees.Add(emp);
            return Ok(emp);
        }

        [HttpGet]
        public IActionResult GetEmployees() => Ok(_service.Employees);
    }
}

