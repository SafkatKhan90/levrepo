﻿using LeaveManagement.Models;

namespace LeaveManagement.Services
{
    public class LeaveService
    {
        public List<Employee> Employees = new();
        public List<LeaveRequest> LeaveRequests = new();

        public bool IsOverlappingLeave(int empId, DateTime from, DateTime to)
        {
            return LeaveRequests.Any(l => l.EmployeeId == empId && l.Status != LeaveStatus.Rejected &&
                ((from >= l.FromDate && from <= l.ToDate) || (to >= l.FromDate && to <= l.ToDate)));
        }

        public bool IsLeaveDurationValid(DateTime from, DateTime to) => (to - from).TotalDays + 1 <= 15;

    }
}
